const puppeteer = require('puppeteer-extra');
const fs = require('fs').promises;
const path = require('path');
const chalk = require('chalk');
const axios = require('axios');
const readline = require('readline');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(StealthPlugin());

async function main() {
    console.clear();
    console.log(chalk.yellow('BOT SEDANG BERJALAN ...')); 
    const browser = await puppeteer.launch({headless: "new"});
    const page = await browser.newPage();
    await page.goto('https://generator.email/prembyadetrio.com');
    const emailSelector = '#email_ch_text';
    await page.waitForSelector(emailSelector);
    const email = await page.$eval(emailSelector, element => element.textContent.trim());
    const checkDomainSet = await page.$eval('#checkdomainset', element => element.textContent.trim());
    console.log('=========================================='); 
    console.log('Email  :', email);
    console.log('Status :', checkDomainSet);
    console.log('=========================================='); 
    await page.close();
    await browser.close();
    await register(email)
}

async function register(email) {
    console.log('\nMembuat Akun ...'); 
    const browser = await puppeteer.launch({
        headless: false,
        args: [
            `--disable-extensions-except=${path.resolve(__dirname, 'capsolver')}`,
            `--load-extension=${path.resolve(__dirname, 'capsolver')}`
        ]
    });
    const page = await browser.newPage();
    await page.goto('https://scribd.com/join', { waitUntil: 'domcontentloaded' });
    const usernameInputSelector = '#email';
    await page.waitForSelector(usernameInputSelector);
    await page.type(usernameInputSelector, email);
    await page.waitForTimeout(1000);
    const passwordInputSelector = '#password';
    await page.waitForSelector(passwordInputSelector);
    await page.type(passwordInputSelector, 'Digital123#');
    await page.waitForTimeout(10000);
    const continueButtonXPath = "//button[contains(., 'Continue')]";
    await page.waitForXPath(continueButtonXPath, { timeout: 3000 });
    const [continueButton] = await page.$x(continueButtonXPath);
    if (continueButton) {
        await continueButton.click();
    } else {
        throw new Error('Tombol Continue tidak ditemukan');
    }
    

    await page.waitForTimeout(3000);
    console.log(chalk.white('\n[ ]    Sedang Memverifikasi Email'));
    const newpage = await browser.newPage();
    await newpage.goto(`https://generator.email/${email}`, { waitUntil: 'domcontentloaded' });
    await newpage.waitForSelector('a.button-scribd.button-primary');
    await newpage.click('a.button-scribd.button-primary');
    await page.waitForTimeout(10000);
    const accountInfo = `\nSCRIBD PREMIUM 1 MONTH\nemail : ${email}\nSandi : Digital123#\n \nAkses Email :\nhttps://generator.email/${email}\n`;
    console.log('[ ] Mengirim Pesan ke Telegram');
    console.log('[ ] Pesan                 :', accountInfo);
    await sendTelegramMessage(accountInfo);
    await sleep(3000)
    await newpage.close();
    await page.close();
    await browser.close();     
}

async function sleep(ms) {return new Promise(resolve => setTimeout(resolve, ms));}
async function sendTelegramMessage(message) {
    try { 
        const token = "6567208624:AAE-L1nD42E-YN3hBPP1XzKf4h-eZ2k4nTA";
        const chatId = "1169647144";
        const response = await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
            chat_id: chatId,
            text: message
        });
        console.log('[ ] Berhasil Mengirim Pesan');
        console.log(chalk.yellow('Menutup Browser')); 
        setTimeout(main, 2000); 
    } catch (error) {
        console.error('Gagal mengirim pesan ke Telegram:', error);
        main();
    }
}

setTimeout(main, 3000); ;
