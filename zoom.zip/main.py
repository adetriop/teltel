import logging
import subprocess
import asyncio
from warnings import filterwarnings
from telegram.warnings import PTBUserWarning

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)
ONE, TWO, START_ROUTES, END_ROUTES = range(4)
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.message.from_user
    logger.info("User %s started the conversation.", user.first_name)
    keyboard = [
        [InlineKeyboardButton("Payco", callback_data=str(ONE)), InlineKeyboardButton("Zoom", callback_data=str(TWO))]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    welcome_message = f"Hi, {user.first_name}!\n\n{update.message.date}\nUser ID: {user.id}\nUsername: {user.username}\n\nSilahkan pilih produk yang ingin kamu jalankan!"
    await update.message.reply_text(welcome_message,  reply_markup=reply_markup)
    return START_ROUTES

async def one(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id
    message_id = query.message.message_id
    await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
    
    # Menjalankan subprocess dan menunggu hingga selesai
    process = subprocess.Popen(['python', 'payco/main.py'])
    return_code = process.wait()
    
    # Log setelah subprocess selesai
    if return_code == 0:
        logger.info("Subprocess Payco selesai dengan sukses.")
        await query.message.reply_text("Bot Payco telah selesai dijalankan.")
    else:
        logger.error("Subprocess Payco gagal.")
        await query.message.reply_text("Bot Payco gagal dijalankan.")
    
    return START_ROUTES

async def two(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id
    message_id = query.message.message_id
    await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
    
    # Menjalankan subprocess dan menunggu hingga selesai
    process = subprocess.Popen(['node', 'zoom/app.js'])
    return_code = process.wait()
    
    # Log setelah subprocess selesai
    if return_code == 0:
        logger.info("Subprocess Zoom selesai dengan sukses.")
        await query.message.reply_text('Bot Zoom telah selesai dijalankan.')
    else:
        logger.error("Subprocess Zoom gagal.")
        await query.message.reply_text('Bot Zoom gagal dijalankan.')
    
    return START_ROUTES


async def start_over(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    keyboard = [
      [InlineKeyboardButton("Payco", callback_data=str(ONE)), InlineKeyboardButton("Zoom", callback_data=str(TWO))]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(text="Silahkan pilih produk yang ingin kamu jalankan!", reply_markup=reply_markup)
    return START_ROUTES

async def end(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(text="See you next time!")
    return ConversationHandler.END

def main() -> None:
    filterwarnings(action="ignore", message=r".*CallbackQueryHandler", category=PTBUserWarning)
    token = "7183139320:AAEcTFrQnI4dMbJhhW3bqhPdgAqRLxjJdp4"
    application = Application.builder().token(token).build()
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            START_ROUTES: [
                CallbackQueryHandler(one, pattern="^" + str(ONE) + "$"),
                CallbackQueryHandler(two, pattern="^" + str(TWO) + "$")
            ],
            END_ROUTES: [
                CallbackQueryHandler(start_over, pattern="^" + str(START_ROUTES) + "$"),
                CallbackQueryHandler(end, pattern="^" + str(END_ROUTES) + "$"),
            ],
        },
        fallbacks=[CommandHandler("start", start)],
    )
    application.add_handler(conv_handler)
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
