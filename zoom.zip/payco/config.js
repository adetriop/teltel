const config = {
tmail_url: "https://tempmail.digitalnetapp.my.id",
tmail_apikey: "PUrH0ZDSgMdL9JRWvKcp",
password: "Digital123#"
}

export default config;