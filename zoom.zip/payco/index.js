import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import readline from 'readline';
import { genEmail, fetchEmail } from './lib/aisbir.js';
import chalk from 'chalk';
import config from './config.js';
import axios from 'axios';

puppeteer.use(StealthPlugin());

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const question = (query) => new Promise(resolve => rl.question(query, resolve));

async function SesiStart(email) {
    let browser;
    try {
        browser = await puppeteer.launch({
            headless: false,
            args: [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-cache",
                "--disable-application-cache",
                "--disk-cache-size=0",
                "--disable-accelerated-2d-canvas",
                "--disable-sync",
                "--no-first-run",
                "--no-zygote",
                "--disable-gpu",
                "--mute-audio",
                "--hide-scrollbars"
            ]
        });
        
        const page = await browser.newPage();
        await page.setDefaultNavigationTimeout(0);
        await page.goto("https://id.payco.com/join.nhn?serviceProviderCode=PAY&inflowKey=www&userLocale=ko_KR&nextURL=https%3A%2F%2Fwww.payco.com%2FafterLogin.nhn", {
            waitUntil: "networkidle2",
        });

        const captchaMessage = await page.evaluate(() => {
            const messageElement = document.querySelector(".h_tit");
            return messageElement ? messageElement.textContent.trim() : null;
        });

        if (captchaMessage === "안전한 이용을 위해 자동 입력 방지 문자를 입력해 주세요.") {
            console.log(chalk.red('\n[INFO] CAPTCHA detected. Please turn on VPN and try again'));
            return "captcha";
        }

        await page.waitForSelector("input#checkboxAll");
        await page.click("input#checkboxAll");
        await page.waitForSelector("button#confirmButton");
        await page.click("button#confirmButton");

        await sleep(5000);

        await page.waitForSelector("span.text.sp_before");
        await page.click("span.text.sp_before");

        await page.waitForSelector("button#popupCancelButton");
        await page.click("button#popupCancelButton");

        await sleep(5000);

        await page.waitForSelector("#emailId", { timeout: 10000 });
        await page.click("#emailId");
        await page.type("#emailId", email);
        console.log(`\nMemasukan Email: ${email}`);

        const password = config.password || "Digital123#";
        await page.type("#password", password);
        console.log('Memasukan Sandi: ' + password);

        await page.waitForSelector("#confirmButton");
        await page.click("#confirmButton");

        await sleep(10000);

        let verifyLink = await fetchEmail(email);
        while (!verifyLink) {
            console.log(chalk.redBright(`[!] Tidak dapat menemukan tautan verifikasi, mencoba lagi...`));
            await sleep(2000);
            verifyLink = await fetchEmail(email);
        }

        console.log(chalk.green(`[+] Tautan verifikasi ditemukan: ${verifyLink}`));

        const verifyPage = await browser.newPage();
        await verifyPage.goto(verifyLink, { waitUntil: "networkidle2" });
        console.log(chalk.green(`[+] Verifikasi email berhasil`));
        const telegramMessage = `email : ${email} \nsandi : Digital123#.\n\nAkses email :\nhttps://tempmail.digitalnetapp.my.id\nbuat email baru dengan email payco`;
        await sendTelegramMessage(telegramMessage);

        return "success";

    } catch (error) {
        console.error("Terjadi kesalahan saat membuat akun:", error.message);
        return "failure";
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

async function sendTelegramMessage(message) {
    try { 
        const token = "7100500033:AAGLbS6rufDg4dYVBe9cmFtcg_0TnfuBUZs";
        const chatId = "1169647144"; 
        const response = await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
            chat_id: chatId,
            text: message
        });
            console.log(chalk.blue('\n[Telegram Information]'));
            console.log(message);
    } catch (error) {
        console.error('Gagal mengirim pesan ke Telegram:', error);
    }
  }

async function start() {
    console.clear();
    console.log(chalk.green('Starting PAYCO account creator...'));

    setTimeout(async () => {
        console.clear();
        const howmany = 10; // Anda dapat mengganti angka ini dengan jumlah akun yang ingin dibuat.
        console.clear();
        console.log(chalk.cyanBright(`[+] Membuat ${howmany} akun...`));

        for (let i = 0; i < howmany; i++) {
            const email = await genEmail();
            const result = await SesiStart(email);
            console.log(result);
            if (result === "captcha") {
                console.log(chalk.red("[INFO] CAPTCHA terdeteksi, hentikan proses pembuatan akun."));
                break;
            } else if (result === "failure") {
                console.log(chalk.red("[INFO] Pembuatan akun gagal."));
            }
        }

        console.log(chalk.greenBright(`[+] Berhasil membuat ${howmany} akun!`));
        sleep(3000).then(() => process.exit(1));
    }, 1000);
}

start();
