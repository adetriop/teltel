const puppeteer = require('puppeteer-extra');
const fs = require('fs').promises;
const path = require('path');
const chalk = require('chalk');
const axios = require('axios');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');

puppeteer.use(StealthPlugin());

async function main() {
    console.clear();
    console.log(chalk.yellow('BOT SEDANG BERJALAN ...'));
    
    const accountCount = 10; // Set to create 5 accounts

    for (let i = 0; i < accountCount; i++) {
        console.log(chalk.green(`\nMembuat akun ke-${i + 1} dari ${accountCount}`));
        
        const browser = await puppeteer.launch({headless: "new"});
        const page = await browser.newPage();
        await page.goto('https://generator.email/prembyadetrio.com');
        const emailSelector = '#email_ch_text';
        await page.waitForSelector(emailSelector);
        const email = await page.$eval(emailSelector, element => element.textContent.trim());
        const checkDomainSet = await page.$eval('#checkdomainset', element => element.textContent.trim());
        console.log('=========================================='); 
        console.log('Email  :', email);
        console.log('Status :', checkDomainSet);
        console.log('=========================================='); 
        await page.close();
        await browser.close();
        await register(email);
    }
}

async function register(email) {
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();
    await page.goto('https://zoom.us/signup');
    const randomYear = Math.floor(Math.random() * (2000 - 1980 + 1)) + 1980;
    const inputSelector = '#app > div > div.layout-main > div > div > div > div > label';
    await page.waitForSelector(inputSelector);
    await page.type(inputSelector, randomYear.toString());
    console.log('[ ] Memasukan tahun Lahir :', chalk.white(randomYear));
    const buttonSelector = '#app > div > div.layout-main > div > div > button';
    await page.waitForSelector(buttonSelector);
    await page.click(buttonSelector);
    const emailInputSelector = '#email';
    await page.waitForSelector(emailInputSelector);
    await page.type(emailInputSelector, email);
    await page.waitForTimeout(1000);
    console.log('[ ] Memasukan Email       :', email);
    const customButtonSelector = '#app > div > div.layout-main > div > div:nth-child(2) > button';
    let customButtonFound = true;
    let attemptCount = 0;
    const maxAttempts = 3;
    while (customButtonFound && attemptCount < maxAttempts) {
        try {
            await page.waitForSelector(customButtonSelector, { timeout: 5000 });
            await page.click(customButtonSelector);
            await page.waitForTimeout(1000);
        } 
        catch (error) {
            customButtonFound = false;
        } 
        finally {
            attemptCount++;
        }
    }    
    const verificationCodeSelector = '#app > div > div.layout-main > div > div.mgt-md.verification-code-wrap > div > input';
    await page.waitForSelector(verificationCodeSelector);
    const newPage = await browser.newPage();
    await newPage.goto(`https://generator.email/${email}`);
    console.log('[ ] Menunggu OTP Email ...');
    let innerText;
    let retryCount = 0;
    const maxRetries = 3;
    while (!innerText && retryCount < maxRetries) {
        try {
            innerText = await newPage.$eval(
                '#email-table > div.e7m.row.list-group-item > div.e7m.col-md-12.ma1 > div.e7m.mess_bodiyy > table > tbody > tr > td > table > tbody > tr:nth-child(2) > td > table > tbody > tr:nth-child(4) > td > div',
                element => element.innerText);
        } 
        catch (error) {}
        if (!innerText) {
            await newPage.reload();
            await newPage.waitForTimeout(2000);
            retryCount++;
        }
    }
    if (innerText) {
        console.log('[ ] OTP Diperoleh         :', innerText);
        await page.bringToFront();
        const verificationCodeSelector = '#app > div > div.layout-main > div > div.mgt-md.verification-code-wrap > div > input';
        await page.waitForSelector(verificationCodeSelector);
        await page.type(verificationCodeSelector, innerText);
        const verifyButtonSelector = '#app > div > div.layout-main > div > div.form-width-sm.verify-btn-wrap.mgt-lg > button';
        await page.waitForSelector(verifyButtonSelector);
        await page.click(verifyButtonSelector);
        const firstNameSelector = '#firstName';
        await page.waitForSelector(firstNameSelector);
        await page.type(firstNameSelector, 'Ade');
        console.log('[ ] Memasukan Nama Depan  : Ade');
        const lastNameSelector = '#lastName';
        await page.waitForSelector(lastNameSelector);
        await page.type(lastNameSelector, 'Trio');
        console.log('[ ] Memasukan Nama Depan  : Trio');
        const passwordValue = 'Digital123#';
        const passwordSelector = 'input[name="password"]';
        await page.waitForSelector(passwordSelector);
        await page.type(passwordSelector, passwordValue);
        console.log('[ ] Memasukan Nama Sandi  : Digital123#');
        const submitButtonSelector = '#app > div > div.layout-main > div > div > button';
        await page.waitForSelector(submitButtonSelector);
        await page.click(submitButtonSelector);
        await page.waitForTimeout(3000);
        const profilePageUrl = 'https://us05web.zoom.us/profile';
        await page.goto(profilePageUrl);
        const twoFactorAuthButtonSelector = '#profile_two_factor_auth > div:nth-child(1) > button';
        await page.waitForSelector(twoFactorAuthButtonSelector);
        await page.click(twoFactorAuthButtonSelector);
        console.log('[ ] Sedang Menyalakan Autentikasi 2 Faktor ...');
        const passwordInputSelector = '#profile_two_factor_auth > div:nth-child(2) > div > div.zm-dialog__body > div > input';
        await page.waitForSelector(passwordInputSelector);
        await page.type(passwordInputSelector, passwordValue);
        const submitButtonSelectors = '#profile_two_factor_auth > div:nth-child(2) > div > div.zm-dialog__footer > span > button.zm-button--primary.zm-button--small.zm-button';
        await page.waitForSelector(submitButtonSelectors);
        await page.click(submitButtonSelectors);
        console.log('[ ] Berhasil Menyalakan Autentikasi 2 Faktor ...');
        const innerTextSelector = '#profile_two_factor_auth > div:nth-child(1) > div > div:nth-child(1)';
        await page.waitForSelector(innerTextSelector);
        await page.$eval(innerTextSelector, element => element.innerText.trim());
    } else {
        console.log(chalk.red('[ ] OTP Tidak Ditemukan !'));
    }
    const accountInfo = `\nZOOM PREMIUM 14 DAYS\nemail : ${email}\nSandi : Digital123#\n \nSudah aktif A2F!!!\nsetelah login akan diarahkan ke web (klik saja lewati)`;
    console.log('[ ] Mengirim Pesan ke Telegram');
    console.log('[ ] Pesan                 :', accountInfo);
    await sendTelegramMessage(accountInfo);
    await browser.close();
    return accountInfo;
}

async function sendTelegramMessage(message) {
    try { 
        const token = "6639495738:AAE5eP5XqHPsU6WBlINKwwlsOdF-EvX7gv8";
        const chatId = "1169647144";
        const response = await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
            chat_id: chatId,
            text: message
        });
        console.log('[ ] Berhasil Mengirim Pesan');
        console.log(chalk.yellow('Menutup Browser')); 
    } catch (error) {
        console.error('Gagal mengirim pesan', error);
    }
}

// Start the main function to create 5 accounts
main();
